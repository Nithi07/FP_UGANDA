
async function loadPage(req, res) {
  res.render('pages/User_Details');
}

module.exports = loadPage;
